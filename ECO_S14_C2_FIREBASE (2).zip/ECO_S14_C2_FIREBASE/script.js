// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDTzfLQki_TgIsuL53NdnyiVgxs5uP8Rv0",
    authDomain: "ecos14multipleclients.firebaseapp.com",
    databaseURL: "https://ecos14multipleclients.firebaseio.com",
    projectId: "ecos14multipleclients",
    storageBucket: "ecos14multipleclients.appspot.com",
    messagingSenderId: "779662695724",
    appId: "1:779662695724:web:c83a542fba0148ad77a089"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
console.log(firebase);

//Se obtienen los accesos a los elementos HTML

let textInputName = document.getElementById("edt_name_index");
let textInputDescription = document.getElementById("edt_describe_index");
let textInputImportancia = document.getElementById("edt_data_index");
let buttonSend = document.getElementById("btn_send_index");

let textInputDeleteName=document.getElementById("edt_name_delete_index");
let buttonDelete = document.getElementById("btn_delete_index");
 

buttonSend.addEventListener("click", function () {
    //Obtenemos todos los valores de los campos de texto    
    let name = textInputName.value;
    let description = textInputDescription.value;
    let importance = textInputImportancia.value;
 
    // llamamos al método encargado de subir a la base de datos y le entregamos los valores
    writeData(name, description, importance);
});

function writeData(name, description, importance) {
    /**
     * el método set() se usa para guardar múltiples ítems bajo una misma referencia
     * user ---> ruta global a la referencia
     *  |- id ---> referencia inicial del set
     *     |-id:userId    
     *     |-name:userName
     *     |-last:userLast
     *     |-email:userEmail
     *     |-phone:userPhone
     * 
     * Todos los eslementos tienen que quedar en llave:valor
     */
    firebase.database().ref('tareas/').push().set({
        nombreActividad: name,
        description: description,
        importance: importance,
    });

    console.log("usuario creado!");
}

// ------------ a partir de este punto elementos para recibir -----------------

// Obtenemos la lista en html
let tareasList = document.getElementById("tareas-list");
// Obtenemos la referencia a la base de datos
let referenciaATareasEnBD = firebase.database().ref('tareas');
// Creamos el listener para cambios sobre usuarios (nuevo hijo)
referenciaATareasEnBD.on('child_added', function (data) {
    // ejecutamos la información con los datos adicionados
    console.log("nueva tarea detectada: " + data.key);
    addNewUser(data.key,data.val().nombreActividad, data.val().description, data.val().importance);
});

function addNewUser(nombre,key, description, importance) {
    let listItem = document.createElement("li");
    listItem.id=key;
    listItem.innerHTML =
    "<div class=\"item-list-style"+key+" \">"+
    ""+"<h4>"+key+"</h4><br><h4>"+description+"</h4><br>"+
    ""+importance+"<br>"+
    ""+"<input type=\"checkbox\" id=\""+key+"\>"+
        "</div>";
    tareasList.appendChild(listItem);    

    let checkbox=document.getElementById(listItem.id);
    
    checkbox.addEventListener('click',function(){
        let referenciaATareasEnBD = firebase.database().ref('tareas/'+nombre+'/'+key);

        console.log("PAPA: "+referenciaATareasEnBD.getParent());
        referenciaATareasEnBD.getParent().remove();
        console.log('edite');
        console.log(listItem.firstChild.id);
        let htmlItem =document.getElementById(key);
        listItem.removeChild(htmlItem);
    });
}

